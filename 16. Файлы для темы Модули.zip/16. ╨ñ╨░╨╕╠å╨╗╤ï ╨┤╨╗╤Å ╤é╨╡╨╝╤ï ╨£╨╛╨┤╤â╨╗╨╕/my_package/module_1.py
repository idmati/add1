# Модуль 1

var_1 = 'Переменная var_1'

def foo_1():
    print('Вызвана foo_1 из my_package.module_1')

