# Модуль 2

from .module_1 import foo_1

def foo_2():
    print('Вызвана foo_2 из my_package.module_2')

foo_1()