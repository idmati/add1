# Модуль 3

var_3 = 'Переменная var_3'

def foo_3():
    print('Вызвана foo_3 из my_package.subpackage.module_3')
