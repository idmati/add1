# pprint для вывода больших списков и словарей в столбик
from pprint import pprint
pprint(dir(__builtins__))