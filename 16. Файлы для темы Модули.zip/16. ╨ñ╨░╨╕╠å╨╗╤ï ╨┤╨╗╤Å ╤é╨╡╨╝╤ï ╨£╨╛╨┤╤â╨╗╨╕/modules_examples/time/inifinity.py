# time для управления временем
# вывод каждый 5 секунд
import time

def hello():
    print('Привет')


# while True:
#     hello()
#     time.sleep(5) 

